let mapOptions={
    center:[35.756720258809594, 51.33667231023504],
    zoom:10
}
let map=new L.map('map',mapOptions);
let layer = new L.TileLayer('http://{s}.tile.openstreetmap.fr/hot/{z}/{x}/{y}.png');

/*let iconOptions={
    title:"location home",
    draggable:true
}*/


map.addLayer(layer);
/*let marker= new L.Marker([35.756720258809594, 51.33667231023504],iconOptions)
marker.addTo(map);*/

let marker=null;
//greftan tool va arz
map.on('click',(event)=>{
    if(marker !== null){
        map.removeLayer(marker);
    }
    marker=L.marker([event.latlng.lat,event.latlng.lng]).addTo(map);
    document.getElementById('latitude').value=event.latlng.lat;
    document.getElementById('longitude').value=event.latlng.lng;
})

/*let _pointA,
    _pointB,
    _polyline,
    markerA=null,
    markerB=null;
    map.on('click',(e)=>{

        if(!_pointA){
            _pointA=e.latlng;
            markerA=L.marker(_pointA).addTo(map);
        }else if(!_pointB){
        _pointB=e.latlng;
        markerB=L.marker(_pointB).addTo(map);
        _polyline=L.polyline([_pointA,_pointB],{color:"red"}).addTo(map);
        let length=map.distance(_pointA,_pointB);
        document.getElementById('length').innerHTML=length;
        }else{
            if(_polyline){
                map.removeLayer(_polyline);
                _polyline=null;
            }
            _pointA=e.latlng;
            map.removeLayer(markerA);
            map.removeLayer(markerB);
            _pointB=null;
            markerA=L.marker(_pointA).addTo(map);
        }

    })*/
