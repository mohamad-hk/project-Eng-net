<?php require_once('header.php'); ?>


<?php
if (isset($_POST['form1'])) {

    $valid = 1;

    if(empty($_POST['keshavarz_name'])) {
        $valid = 0;
        $error_message .= "نام کشاورز نمی تواند خالی باشد"."<br>";
    }

    if(empty($_POST['keshavarz_email'])) {
        $valid = 0;
        $error_message .= "ایمیل نمی تواند خالی باشد"."<br>";
    } else {
        if (filter_var($_POST['keshavarz_email'], FILTER_VALIDATE_EMAIL) === false) {
            $valid = 0;
            $error_message .= "ایمیل را به درستی وارد کنید"."<br>";
        }
    }

    if(empty($_POST['keshavarz_phone'])) {
        $valid = 0;
        $error_message .= "شماره موبایل نمی تواند خالی باشد"."<br>";
    }

    if(empty($_POST['keshavarz_address'])) {
        $valid = 0;
        $error_message .= "آدرس نمی تواند خالی باشد"."<br>";
    }

    if(empty($_POST['keshavarz_city'])) {
        $valid = 0;
        $error_message .= "شهر نمی تواند خالی باشد"."<br>";
    }

    if( empty($_POST['keshavarz_password']) || empty($_POST['keshavarz_re_password']) ) {
        $valid = 0;
        $error_message .= "رمز عبور نمی تواند خالی باشد"."<br>";
    }

    if( !empty($_POST['keshavarz_password']) && !empty($_POST['keshavarz_re_password']) ) {
        if($_POST['keshavarz_password'] != $_POST['keshavarz_re_password']) {
            $valid = 0;
            $error_message .= "رمز عبور مطابفت ندارد"."<br>";
        }
    }

    if($valid == 1) {

        $token = md5(time());
        $cust_datetime = date('Y-m-d h:i:s');
        $cust_timestamp = time();

        // saving into the database
        $statement = $pdo->prepare("INSERT INTO tbl_keshavarz ( keshavarz_name,keshavarz_email, keshavarz_phone, keshavarz_address, keshavarz_city,keshavarz_password,role,status, cust_status,keshavarz_latitude,keshavarz_longitude) VALUES (?,?,?,?,?,?,?,?,?,?,?)");
        $statement->execute(array(strip_tags($_POST['keshavarz_name']),strip_tags($_POST['keshavarz_email']),strip_tags($_POST['keshavarz_phone']),strip_tags($_POST['keshavarz_address']),strip_tags($_POST['keshavarz_city']),md5($_POST['keshavarz_password']),"admin","Active", 1,strip_tags($_POST['keshavarz_latitude']),strip_tags($_POST['keshavarz_longitude'])));
        
        $statement1 = $pdo->prepare("INSERT INTO user(username,password,uname,photo,access) VALUES (?,?,?,?,?)");
        $statement1->execute(array(strip_tags($_POST['keshavarz_name']),md5($_POST['keshavarz_password']),$_POST['keshavarz_name'].'(keshavarz)',"",2));
        header('Location: login.php');
        
   
     } 	header('location: index.php');
    }

?>

<div class="page-banner" style="background-color:#444;background-image: url(assets/uploads/<?php echo $banner_registration; ?>);">
    <div class="inner">
    </div>
</div>

<div class="page">
    <div class="container" style=" text-align:right;">
        <div class="row">
            <div class="col-md-12">
                <div class="user-content" style="margin-top: 50px;" >
                    <form action="" method="post">
                        <?php $csrf->echoInputField(); ?>
                        <div class="row">
                            <div class="col-md-12">
                                
                                <?php
                                if($error_message != '') {
                                    echo "<div class='error' style='padding: 10px;background:#f1f1f1;margin-bottom:20px;'>".$error_message."</div>";
                                }
                                if($success_message != '') {
                                    echo "<div class='success' style='padding: 10px;background:#f1f1f1;margin-bottom:20px;'>".$success_message."</div>";
                                }
                                ?>

                                <div class="col-md-6 form-group">
                                    <label for="">نام و نام خانوادگی *</label>
                                    <input type="text" class="form-control" style=" text-align:right;" name="keshavarz_name" value="<?php if(isset($_POST['keshavarz_name'])){echo $_POST['keshavarz_name'];} ?>">
                                </div>
                                <div class="col-md-6 form-group">
                                    <label for="">ایمیل *</label>
                                    <input type="email" class="form-control" style=" text-align:right;" name="keshavarz_email" value="<?php if(isset($_POST['keshavarz_email'])){echo $_POST['keshavarz_email'];} ?>">
                                </div>
                                <div class="col-md-6 form-group">
                                    <label for="">شماره موبایل *</label>
                                    <input type="text" class="form-control" style=" text-align:right;" name="keshavarz_phone" value="<?php if(isset($_POST['keshavarz_phone'])){echo $_POST['keshavarz_phone'];} ?>">
                                </div>
                                
                                <div class="col-md-6 form-group">
                                    <label for="">شهر *</label>
                                    <input type="text" class="form-control" style=" text-align:right;" name="keshavarz_city" value="<?php if(isset($_POST['keshavarz_city'])){echo $_POST['keshavarz_city'];} ?>">
                                </div>
                                <div class="col-md-12 form-group">
                                    <label for="">آدرس *</label>
                                    <textarea name="keshavarz_address" class="form-control" style=" text-align:right;" cols="30" rows="10" style="height:70px;"><?php if(isset($_POST['keshavarz_address'])){echo $_POST['keshavarz_address'];} ?></textarea>
                                </div>
                                
                                <div class="col-md-6 form-group">

                                    <label for="">رمز عبور *</label>
                                    <input type="password" class="form-control" style=" text-align:right;" name="keshavarz_password">

                                </div>
                                <div class="col-md-6 form-group">

                                <label for="">تایید رمز عبور *</label>
                                    <input type="password" class="form-control" style=" text-align:right;" name="keshavarz_re_password">
                                </div>
                                <div class="col-md-12 form-group">
                                    <label for=""></label>
                                    <input type="Submit" class="btn btn-danger" value="ثبت نام" name="form1">
                                </div>
                                <div class="col-md-6 form-group">
                                    <label for="">موقعیت خانه خود را مشخص کنید *</label><br>
                                    <input type="text" class="form-control" id="latitude" placeholder="latitude" name="keshavarz_latitude">
                                    <input type="text" class="form-control" id="longitude" placeholder="longitude" name="keshavarz_longitude">
                                 <!--span id="length"></span-->
                               

                                <div id="map"></div>

                                </div>
                            </div>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
</div>
<script src="https://unpkg.com/leaflet@1.9.3/dist/leaflet.js" integrity="sha256-WBkoXOwTeyKclOHuWtc+i2uENFpDZ9YPdf5Hf+D7ewM=" crossorigin=""></script>
<script src="js/scripts.js"></script>
