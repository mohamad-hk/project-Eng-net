<?php require_once('header.php'); ?>

<?php
  ;
$error_message = '';
if(isset($_POST['form1'])) {

    $i = 0;
    $statement = $pdo->prepare("SELECT * FROM tbl_product");
    $statement->execute();
    $result = $statement->fetchAll(PDO::FETCH_ASSOC);
    foreach ($result as $row) {
        $i++;
        $table_product_id[$i] = $row['p_id'];
        $table_quantity[$i] = $row['p_qty'];
    }

    $i=0;
    foreach($_POST['product_id'] as $val) {
        $i++;
        $arr1[$i] = $val;
    }
    $i=0;
    foreach($_POST['quantity'] as $val) {
        $i++;
        $arr2[$i] = $val;
    }
    $i=0;
    foreach($_POST['product_name'] as $val) {
        $i++;
        $arr3[$i] = $val;
    }
    
    $allow_update = 1;
    for($i=1;$i<=count($arr1);$i++) {
        for($j=1;$j<=count($table_product_id);$j++) {
            if($arr1[$i] == $table_product_id[$j]) {
                $temp_index = $j;
                break;
            }
        }
        if($table_quantity[$temp_index] < $arr2[$i]) {
        	$allow_update = 0;
            $error_message .= '"'.$arr2[$i].'" items are not available for "'.$arr3[$i].'"\n';
        } else {
            $_SESSION['cart_p_qty'][$i] = $arr2[$i];
        }
    }
    $error_message .= '\nOther items quantity are updated successfully!';
    ?>
    
    <?php if($allow_update == 0): ?>
    	<script>alert('<?php echo $error_message; ?>');</script>
	<?php else: ?>
		<script>alert('تعداد محصولات آپدیت شد');</script>
	<?php endif; ?>
    <?php

}
?>

<div class="page-banner" style="background-image: url(assets/uploads/<?php echo $banner_cart; ?>)">
    <div class="overlay"></div>
    <div class="page-banner-inner">
        <h1>سبد خرید</h1>
    </div>
</div>

<div class="page">
	<div class="container">
		<div class="row">
			<div class="col-md-12">

                <?php if(!isset($_SESSION['cart_p_id'])): ?>
                    <?php echo '<h2 class="text-center">سبد خرید خالی است</h2></br>'; ?>
                <?php else: ?>
                <form action="" method="post">
                    <?php $csrf->echoInputField(); 
                    
                    ?>
				<div class="cart">
                    <table class="table table-responsive table-hover table-bordered">
                        <tr>
                            <th style="text-align:center" ><?php echo '#' ?></th>
                            <th style="text-align:center" >عکس محصول</th>
                            <th style="text-align:center" >نام محصول</th>
                            <th style="text-align:center" >نام کشاورز</th>
                            <th style="text-align:center" >نوع بسته بندی</th>
                            <th style="text-align:center" >قیمت </th>
                            <th style="text-align:center" >تعداد</th>
                            <th style="text-align:center"  class="text-right">مجموع</th>
                            <th style="text-align:center"  class="text-center" style="width: 100px;">عملیات</th>
                        </tr>
                        <?php
                        $table_total_price = 0;

                        $i=0;
                        foreach($_SESSION['cart_p_id'] as $key => $value) 
                        {
                            $i++;
                            $arr_cart_p_id[$i] = $value;
                        }
                        $i=0;
                        foreach($_SESSION['cart_keshavarz_id'] as $key => $value) 
                        {
                            $i++;
                            $arr_cart_keshavarz_id[$i] = $value;
                        }

                        $i=0;
                        foreach($_SESSION['cart_keshavarz_name'] as $key => $value) 
                        {
                            $i++;
                            $arr_cart_keshavarz_name[$i] = $value;
                        }

                        $i=0;
                        foreach($_SESSION['cart_category_id'] as $key => $value) 
                        {
                            $i++;
                            $arr_cart_category_id[$i] = $value;
                        }

                        $i=0;
                        foreach($_SESSION['cart_category_name'] as $key => $value) 
                        {
                            $i++;
                            $arr_cart_category_name[$i] = $value;
                        }

                        $i=0;
                        foreach($_SESSION['cart_p_qty'] as $key => $value) 
                        {
                            $i++;
                            $arr_cart_p_qty[$i] = $value;
                        }

                        $i=0;
                        foreach($_SESSION['cart_p_current_price'] as $key => $value) 
                        {
                            $i++;
                            $arr_cart_p_current_price[$i] = $value;
                        }

                        $i=0;
                        foreach($_SESSION['cart_p_name'] as $key => $value) 
                        {
                            $i++;
                            $arr_cart_p_name[$i] = $value;
                        }

                        $i=0;
                        foreach($_SESSION['cart_p_featured_photo'] as $key => $value) 
                        {
                            $i++;
                            $arr_cart_p_featured_photo[$i] = $value;
                        }
                        ?>
                        <?php for($i=1;$i<=count($arr_cart_p_id);$i++): ?>
                        <tr>
                            <td><?php echo $i; ?></td>
                            <td>
                                <img src="assets/uploads/<?php echo $arr_cart_p_featured_photo[$i]; ?>" alt="">
                            </td>
                            <td style="text-align:center"><?php echo $arr_cart_p_name[$i]; ?></td>
                            <td style="text-align:center"><?php echo $arr_cart_keshavarz_name[$i]; ?></td>
                            <td style="text-align:center"><?php echo $arr_cart_category_name[$i]; ?></td>
                            <td style="text-align:center"><?php echo $arr_cart_p_current_price[$i]; ?></td>
                            <td style="text-align:center">
                                <input type="hidden" name="product_id[]" value="<?php echo $arr_cart_p_id[$i]; ?>">
                                <input type="hidden" name="product_name[]" value="<?php echo $arr_cart_p_name[$i]; ?>">
                                <input type="number" class="input-text qty text" step="1" min="1" max="" name="quantity[]" value="<?php echo $arr_cart_p_qty[$i]; ?>" title="Qty" size="4" pattern="[0-9]*" inputmode="numeric">
                            </td>
                            <td class="text-right">
                                <?php
                            $row_total_price = $arr_cart_p_current_price[$i]*$arr_cart_p_qty[$i];
                            $table_total_price = $table_total_price + $row_total_price;

                            $statement1 = $pdo->prepare("SELECT * FROM tbl_discount");
                            $statement1->execute();
                            $result1 = $statement1->fetchAll(PDO::FETCH_ASSOC);
                            foreach ($result1 as $row1) {
                                if($_POST['discountcode'] == $row1['discount_code']){
                                    if($row1['code_status']=="active"){
                                    $_SESSION['discountcode']=$row1['discount_code'];
                                    $_SESSION['discountid']=$row1['discount_id'];
                                    $_SESSION['discountvalue1']=$row1['discount_value'];
                                    $table_total_price=$table_total_price-$row1['discount_value'];
                                    $_SESSION['discount-value']= $table_total_price;
                                    
                                    }
                                }
                                
                                else{
                                    $table_total_price=$table_total_price;
                                    $_SESSION['discount-value']=$table_total_price;
                                }
                            }
                                ?>
                               <?php echo $row_total_price; ?>
                            </td>
                            <td class="text-center">
                                <a onclick="return confirmDelete();" href="cart-item-delete.php?id=<?php echo $arr_cart_p_id[$i]; ?>&size=<?php echo $arr_cart_keshavarz_id[$i]; ?>&color=<?php echo $arr_cart_category_id[$i]; ?>" class="trash"><i class="fa fa-trash" style="color:red;"></i></a>
                            </td>
                        </tr>
                        <?php endfor; ?>
                        <tr>
                            <th colspan="7" class="total-text">مجموع</th>
                            <th class="total-amount"><?php echo $table_total_price; ?></th>
                            <th></th>
                        </tr>
                    </table> 
                    <div> 
                            کد تخفیف <input type="text" name="discountcode"> <input type="Submit">

                     </div>
                </div>

                <div class="cart-buttons">
                    <ul>
                        <li><input type="Submit" value="به روز رسانی سبد خرید" class="btn btn-primary" name="form1"></li>
                        <li><a href="index.php" class="btn btn-primary">ادامه خرید</a></li>
                        <li><a href="checkout.php" class="btn btn-primary">پرداخت</a></li>
                    </ul>
                </div>
                </form>
                <?php endif; ?>
			</div>
		</div>
	</div>
</div>


<?php require_once('footer.php'); ?>