<!DOCTYPE html>
<html>
<head>
	<title>اتاق گفتگو</title>

<style>
	body{
		background: #d2d6de;
	}
	#login_form{
		border-redius:5px;
		width:350px;
		height:150px;
		position:relative;
		top:250px;
		margin: auto;
		padding: auto;
		background:#FFFFFF;
	}
</style>
</head>
<body>
<div class="container">
	<div id="login_form" class="well">
		<h2><center><span class="glyphicon glyphicon-lock"></span> وارد شوید</center></h2>
		<hr>
		<form method="POST" action="login.php">
		نام کاربری: <input type="text" name="username" class="form-control" required>
		<div style="height: 10px;"></div>		
		رمز عبور: <input type="password" name="password" class="form-control" required> 
	
		<button type="Submit" class="btn btn-primary"><span class="glyphicon glyphicon-log-in"></span> ورود</button> 
		</form>
		<div style="height: 15px;"></div>
		<div style="color: red; font-size: 15px;">
			<center>
			<?php
				session_start();
				if(isset($_SESSION['msg'])){
					echo $_SESSION['msg'];
					unset($_SESSION['msg']);
				}
			?>
			</center>
		</div>
	</div>
</div>
</body>
</html>