
<?php
include("config.php");
ob_start();
session_start();
		$fullname=$_POST['username'];
		$fpassword=md5($_POST['password']);
		$m=$pdo->prepare("SELECT * from user where username=? and password=?");
		$m->execute(array($fullname,$fpassword));
		$total=$m->rowCount();
		$result = $m->fetchAll(PDO::FETCH_ASSOC);
		if($total==0){
			echo "کلمه عبور یا رمز عبور اشتباه است";
			header('Location: index.php');
		}
		foreach($result as $row) {
			if($row['username']==$fullname){
				if($row['access']==1){
					$_SESSION['username']=$fullname;
					$_SESSION['id']=$row['userid'];
					
					header('Location: admin/');
				}
				else{
					$_SESSION['username']=$fullname;
					$_SESSION['id']=$row['userid'];
					header('Location: user/index.php');
				}

			}

			}
		
?>