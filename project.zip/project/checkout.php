<?php require_once('header.php');  ?>

<?php
$stack=array();
$cost=array();

  ;
?>

<?php
if(!isset($_SESSION['cart_p_id'])) {
    header('location: cart.php');
    exit;
}
?>

<?php
function getDistance($latitude1, $longitude1) {
        $theta = $_SESSION['customer']['cust_longitude'] - $longitude1;
        $distance = (sin(deg2rad($_SESSION['customer']['cust_latitude'])) * sin(deg2rad($latitude1))) + (cos(deg2rad($_SESSION['customer']['cust_latitude'])) * cos(deg2rad($latitude1)) * cos(deg2rad($theta))); 
        $distance = acos($distance); 
        $distance = rad2deg($distance); 
        $distance = $distance * 60 * 1.1515; 
        $distance = $distance * 1.609344; 
        return (round($distance,0)); 
      }
    
?>

<div class="page">
    <div class="container">
        <div class="row">
            <div class="col-md-12">
                
                <?php if(!isset($_SESSION['customer'])): ?>
                    <p>
                        <a href="login.php" class="btn btn-md btn-danger">لطفا وارد سایت شوید</a>
                    </p>
                <?php else: ?>

                <h3 class="special">جزیات سفارش</h3>
                <div class="cart">
                    <table class="table table-responsive table-hover table-bordered">
                        <tr>
                            <th style="text-align:center"><?php echo '#' ?></th>
                            <th style="text-align:center">عکس محصول</th>
                            <th style="text-align:center">نام محصول</th>
                            <th style="text-align:center">نام کشاورز</th>
                            <th style="text-align:center">نوع بسته بندی</th>

                            <th style="text-align:center" class="text-right">مجموع</th>
                            <th style="text-align:center">تعداد</th>
                            <th style="text-align:center">قیمت نهایی</th>
                        </tr>
                         <?php
                        $table_total_price = 0;

                        $i=0;
                        foreach($_SESSION['cart_p_id'] as $key => $value) 
                        {
                            $i++;
                            $arr_cart_p_id[$i] = $value;
                        }


                        $i=0;
                        foreach($_SESSION['cart_keshavarz_name'] as $key => $value) 
                        {
                            $i++;
                            $arr_cart_keshavarz_name[$i] = $value;
                        }


                        $i=0;
                        foreach($_SESSION['cart_category_name'] as $key => $value) 
                        {
                            $i++;
                            $arr_cart_category_name[$i] = $value;
                        }

                        $i=0;
                        foreach($_SESSION['cart_p_qty'] as $key => $value) 
                        {
                            $i++;
                            $arr_cart_p_qty[$i] = $value;
                        }

                        $i=0;
                        foreach($_SESSION['cart_p_current_price'] as $key => $value) 
                        {
                            $i++;
                            $arr_cart_p_current_price[$i] = $value;
                        }

                        $i=0;
                        foreach($_SESSION['cart_p_name'] as $key => $value) 
                        {
                            $i++;
                            $arr_cart_p_name[$i] = $value;
                        }

                        $i=0;
                        foreach($_SESSION['cart_p_featured_photo'] as $key => $value) 
                        {
                            $i++;
                            $arr_cart_p_featured_photo[$i] = $value;
                        }
                        ?>
                        <?php for($i=1;$i<=count($arr_cart_p_id);$i++): ?>
                        <tr>
                            <td><?php echo $i; ?></td>
                            <td>
                                <img src="assets/uploads/<?php echo $arr_cart_p_featured_photo[$i]; ?>" alt="">
                            </td>
                            <td style="text-align:center"><?php echo $arr_cart_p_name[$i]; ?></td>
                            <td style="text-align:center"><?php echo $arr_cart_keshavarz_name[$i]; array_push($stack,$arr_cart_keshavarz_name[$i]);?></td>
                            <td style="text-align:center"><?php echo $arr_cart_category_name[$i]; ?></td>
                            <td style="text-align:center"><?php echo $arr_cart_p_current_price[$i]; ?></td>
                            <td style="text-align:center"><?php echo $arr_cart_p_qty[$i]; ?></td>
                            <td style="text-align:center" class="text-right">
                                <?php
                                $row_total_price = $arr_cart_p_current_price[$i]*$arr_cart_p_qty[$i];
                                $table_total_price = $table_total_price + $row_total_price;
                                $table_total_price=$_SESSION['discount-value'];
                                ?>
                            <?php echo $row_total_price; ?>
                            </td>
                        </tr>
                        <?php endfor; ?>
                        <?php
                        if($_SESSION['discountvalue1']!=0){
                            ?>
                            <td colspan="7" class="total-text"><?php echo "تخفیف اعمال شده"; ?></td>
                            <td class="total-amount"><?php echo $_SESSION['discountvalue1']; ?></td>
                        <?php
                        }elseif ($_SESSION['discountvalue1']==0) {
                            ?>
                            
                            <td colspan="7" class="total-text"><?php echo "تخفیف اعمال شده"; ?></td>
                            <td class="total-amount"><?php echo "0"; ?></td>
                            <?php
                        }
                        ?>

                        <tr>
                            <th colspan="7" class="total-text"><?php echo"قیمت نهایی" ?></th>
                            <th class="total-amount"><?php echo $table_total_price; ?></th>
                        </tr>


                        <?php
                            for($i=0;$i<count($stack);$i++){
                            $temp=$stack[$i];
                            
                            $statement1 =$pdo->prepare("SELECT * FROM tbl_keshavarz WHERE keshavarz_name='$temp'");
                            $statement1->execute();
                            $result1 = $statement1->fetchAll(PDO::FETCH_ASSOC);
                            $temp_value=getDistance($result1[0][ 'keshavarz_latitude' ], $result1[0][ 'keshavarz_longitude' ]);
                            array_push($cost,$temp_value);
                           
                            }
                            $shipping_cost =array_sum(array_unique($cost));
                            $shipping_cost=$shipping_cost*1000;
                            $_SESSION['shipping_cost']=$shipping_cost;
                        ?>

                        <tr>
                            <td colspan="7" class="total-text">هزینه حمل و نقل</td>
                            <?php if($table_total_price>2000000){$shipping_cost=0;}elseif($table_total_price>1000000){$shipping_cost=$shipping_cost/2;} ?>
                            <td class="total-amount"><?php echo $shipping_cost; ?></td>
                        </tr>

                        <tr>
                            <th colspan="7" class="total-text">مجموع</th>
                            <th class="total-amount">
                                <?php
                                $final_total = $table_total_price+$shipping_cost;
                                
                                ?>
                                <?php echo $final_total; ?>
                            </th>
                        </tr>
                    </table> 
                </div>

                

                <div class="billing-address">
                    <div class="row">
                        <div class="col-md-6">
                            <h3 class="special">آدرس صورت حساب</h3>
                            <table class="table table-responsive table-bordered table-hover table-striped bill-address">
                                <tr><td><?php echo $_SESSION['customer']['cust_b_name']; ?></p></td>
                                    <td>نام و نام خانوادگی </td>
                                    
                                </tr>
                                <tr><td><?php echo $_SESSION['customer']['cust_b_cname']; ?></td>
                                    <td>نام شرکت </td>
                                    
                                </tr>
                                <tr>  
                                     <td><?php echo $_SESSION['customer']['cust_b_phone']; ?></td>
                                    <td>شماره تماس</td>
                                 
                                </tr>
                                <tr>
                                   
                                    

                                    <td><?php echo $_SESSION['customer']['cust_b_state']; ?></td>

                                    <td>استان</td>
                                </tr>
                                <tr>
                                    <td>
                                        <?php echo nl2br($_SESSION['customer']['cust_b_address']); ?>
                                    </td>
                                    <td>آدرس</td>
                                    
                                </tr>
                                <tr>
                                    <td><?php echo $_SESSION['customer']['cust_b_city']; ?></td>
                                    <td>شهرستان</td>
                                    
                                </tr>
                                <tr>
                                    <td><?php echo $_SESSION['customer']['cust_b_state']; ?></td>
                                    <td>محله</td>
                                    
                                </tr>
                                <tr>
                                    <td><?php echo $_SESSION['customer']['cust_b_zip']; ?></td>
                                    <td>کد پستی</td>
                                    
                                </tr>
                            </table>
                        </div>
                        <div class="col-md-6">
                            <h3 class="special">آدرس ارسال</h3>
                            <table class="table table-responsive table-bordered table-hover table-striped bill-address">
                                <tr>
                                    <td><?php echo $_SESSION['customer']['cust_s_name']; ?></p></td>
                                    <td>نام و نام خانوادگی </td>
                                    
                                </tr>
                                <tr>
                                    <td><?php echo $_SESSION['customer']['cust_s_cname']; ?></td>
                                    <td>نام شرکت </td>
                                    
                                </tr>
                                <tr>
                                    <td><?php echo $_SESSION['customer']['cust_s_phone']; ?></td>
                                    <td>شماره تماس</td>
                                    
                                </tr>
                                <tr>
                                    
                                <td><?php echo $_SESSION['customer']['cust_s_state']; ?></td>
                                 
                                    <td>استان</td>
                                </tr>
                                <tr>
                                    
                                    <td>
                                        <?php echo nl2br($_SESSION['customer']['cust_s_address']); ?>
                                    </td>
                                    <td>آدرس</td>
                                </tr>
                                <tr>
                                    <td><?php echo $_SESSION['customer']['cust_s_city']; ?></td>
                                    <td>شهرستان</td>
                                    
                                </tr>
                                <tr>
                                    <td><?php echo $_SESSION['customer']['cust_s_state']; ?></td>
                                    <td>محله</td>
                                    
                                </tr>
                                <tr>
                                    <td><?php echo $_SESSION['customer']['cust_s_zip']; ?></td>
                                    <td>کد پستی</td>
                                    
                                </tr> 
                            </table>
                        </div>
                    </div>
                </div>

                

                <div class="cart-buttons">
                    <ul>
                        <li><a href="cart.php" class="btn btn-primary">بازگشت به سبد خرید</a></li>
                    </ul>
                </div>

				<div class="clear"></div>
        
                <div class="row">
                    
                    	<?php
		                $checkout_access = 1;
		                if(
		                    ($_SESSION['customer']['cust_b_name']=='') ||
		                    ($_SESSION['customer']['cust_b_cname']=='') ||
		                    ($_SESSION['customer']['cust_b_phone']=='') ||
		                    ($_SESSION['customer']['cust_b_address']=='') ||
		                    ($_SESSION['customer']['cust_b_city']=='') ||
		                    ($_SESSION['customer']['cust_b_state']=='') ||
		                    ($_SESSION['customer']['cust_b_zip']=='') ||
		                    ($_SESSION['customer']['cust_s_name']=='') ||
		                    ($_SESSION['customer']['cust_s_cname']=='') ||
		                    ($_SESSION['customer']['cust_s_phone']=='') ||
		                    ($_SESSION['customer']['cust_s_address']=='') ||
		                    ($_SESSION['customer']['cust_s_city']=='') ||
		                    ($_SESSION['customer']['cust_s_state']=='') ||
		                    ($_SESSION['customer']['cust_s_zip']=='')
		                ) {
		                    $checkout_access = 0;
		                }
		                ?>
		                <?php if($checkout_access == 0): ?>
		                	<div class="col-md-12">
				                <div style="color:red;font-size:22px;margin-bottom:50px;">
			                       ابتدا آدرس صورت حساب و آدرس ارسال را وارد کنید <a href="customer-billing-shipping-update.php" style="color:red;text-decoration:underline;">از طریق این لینک</a>.
			                    </div>
	                    	</div>
	                	<?php else: ?>
		                	<div class="col-md-4">
	                            <div class="row">
                                    <form action="init.php" method="post" id="bank_form">
                                        <input type="hidden" name="amount" value="<?php echo $final_total; ?>">
                                        <div class="col-md-12 form-group">
                                            <input type="Submit" class="btn btn-primary" value="<?php echo 'پرداخت'; ?>" name="form3">
                                        </div>
                                    </form>
	                            </div>
		                    </div>
		                <?php endif; ?>
                </div>
                <?php endif; ?>
            </div>
        </div>
    </div>
</div>


<?php require_once('footer.php'); ?>