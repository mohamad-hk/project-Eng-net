<div class="user-sidebar">
    <ul>
    <a href="dashboard.php"><button class="btn btn-danger">داشبورد </button></a>
    <a href="customer-profile-update.php"><button class="btn btn-danger">ویرایش اطلاعات</button></a>
    <a href="customer-billing-shipping-update.php"><button class="btn btn-danger">ویرایش آدرس</button></a>
    <a href="customer-order.php"><button class="btn btn-danger">سفارشات</button></a>
    <a href="logout.php"><button class="btn btn-danger">خروج</button></a>
    </ul>
</div>