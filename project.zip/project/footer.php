
	<div class="container">
		<div class="row">
			
		<div class="col-12 col-sm-12 col-md-2 col-lg-2 col-xl-2 col-xxl-2" id="list-footer">
              <ul class="list-unstyled lh-lg">
              <li> <a class="text-decoration-none" href="#"><i class="fa fa-rss"></i>تازه ترین اخبار</a> <p class="color-text-custom-2">تازه ترین اخبار و اطلاعیه های نوین چرم</p> </li>
              <li> <a class="text-decoration-none" href="#"><i class="bi bi-play-circle"></i>چند رسانه ای</a><p class="color-text-custom-2">تصاویر،ویدیوها و کاتالوگ ها</p> </li>
              <li> <a class="text-decoration-none" href="#"><i class="bi bi-info-circle"></i>درباره نوین چرم</a> </li>
              <li class=""> <i class="bi bi-telephone-fill"></i>تماس با ما</li>
            </ul>
          </div>
            <div class="col-12 col-sm-12 col-md-2 col-lg-2 col-xl-2 col-xxl-2" id="list-footer">
              <ul class="list-unstyled lh-lg">
              <li><a class="text-decoration-none font-size-footer-heading fw-bold" href="#">خدمات مشتریان</a></li>
              <li><a class="text-decoration-none" href="#">سوالات متداول</a></li>
              <li><a class="text-decoration-none" href="#">خدمات پس از فروش</a></li>
              <li><a class="text-decoration-none" href="#">شارژ کارت باشگاه مشتریان</a></li>
              <li><a class="text-decoration-none" href="#">نگهداری از محصولات چرمی</a></li>
              <li><a class="text-decoration-none" href="#">شیوه تعویض و عودت محصول</a></li>
            </ul>
          </div>
            <div class="col-12 col-sm-12 col-md-2 col-lg-2 col-xl-2 col-xxl-2" id="list-footer">
              <ul class="list-unstyled lh-lg">
              <li><a class="text-decoration-none  font-size-footer-heading fw-bold" href="#">با نوین چرم</a></li>
              <li><a class="text-decoration-none  " href="#">فروش سازمانی</a></li>
              <li><a class="text-decoration-none  " href="#">آدرس فروشگاه ها</a></li>
              <li><a class="text-decoration-none  " href="#">همکاری با ما</a></li>
              <li><a class="text-decoration-none  " href="#">چرم بلاگ</a></li>
            </ul>
          </div>
            <div class="col-12 col-sm-12 col-md-2 col-lg-2 col-xl-2 col-xxl-2 " id="list-footer">
              <ul class="list-unstyled lh-lg">
              <li><a class="text-decoration-none font-size-footer-heading fw-bold" href="#">راهنمای خرید آنلاین</a></li>
              <li><a class="text-decoration-none " href="#">شرایط و مقررات</a></li>
              <li><a class="text-decoration-none " href="#">نحوه ثبت سفارش</a></li>
              <li><a class="text-decoration-none " href="#">روش های پرداخت سفارش</a></li>
              <li><a class="text-decoration-none " href="#">شیوه های ارسال سفارش</a></li>
              <li><a class="text-decoration-none " href="#">پیگیری سفارش آنلاین</a></li>
            </ul>
          </div>
            <div class="col-12 col-sm-12 col-md-1 col-lg-1 col-xl-1 col-xxl-1 text-center " id="last-list-footer">
              <ul class="list-unstyled">
              <li class=" d-inline-block color-text-custom-2 text-center custom-font-footer mb-3"><i class="bi bi-credit-card fs-4"></i> <p>پرداخت اینترنتی</p> </li>
              <li class=" d-inline-block color-text-custom-2 text-center custom-font-footer"><i class="fa fa-truck fs-3 py-1"></i> <p>ارسال سفارش</p> </li>
            </ul>
          </div>
          </div>
        </div>
      <div>
          <p class="text-start border border-1 border-secondary  border-end-0 border-bottom-0 border-start-0 color-text-custom-2 ">  .All Rights Reserved نوین چرم<i class="bi bi-c-circle"></i>copyright 2022</p>
      </div>
		</div>
	</div>



<a href="#" class="scrollup">
	<i class="fa fa-angle-up"></i>
</a>


<script src="assets/js/jquery-2.2.4.min.js"></script>
<script src="assets/js/bootstrap.min.js"></script>
<script src="https://js.stripe.com/v2/"></script>
<script src="assets/js/megamenu.js"></script>
<script src="assets/js/owl.carousel.min.js"></script>
<script src="assets/js/owl.animate.js"></script>
<script src="assets/js/jquery.bxslider.min.js"></script>
<script src="assets/js/jquery.magnific-popup.min.js"></script>
<script src="assets/js/rating.js"></script>
<script src="assets/js/jquery.touchSwipe.min.js"></script>
<script src="assets/js/bootstrap-touch-slider.js"></script>
<script src="assets/js/select2.full.min.js"></script>
<script src="assets/js/custom.js"></script>
<script>
	
  $(".select-state").on('change',function(){
    var id=$(this).val();
    var dataString = 'id='+ id;
    $.ajax
    ({
      type: "POST",
      url: "get-city.php",
      data: dataString,
      cache: false,
      success: function(html)
      {
        $(".select-city").html(html);
      }
    });			
  });
</script>
</body>
</html>