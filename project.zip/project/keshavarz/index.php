<?php require_once('header.php'); ?>

<section class="content-header">
	<h1>داشبورد</h1>
</section>

<?php
$balance=array();

$temp=$_SESSION['keshavarz_name'];
$statement = $pdo->prepare("SELECT * FROM tbl_payment INNER JOIN tbl_order ON tbl_payment.payment_id=tbl_order.payment_id  WHERE payment_status=? AND keshavarz='$temp'");
$statement->execute(array('تکمیل پرداخت'));
$total_order_completed = $statement->rowCount();

$statement = $pdo->prepare("SELECT * FROM tbl_payment INNER JOIN tbl_order ON tbl_payment.payment_id=tbl_order.payment_id WHERE shipping_status=? AND keshavarz='$temp'");
$statement->execute(array('تکمیل پرداخت'));
$total_shipping_completed = $statement->rowCount();

$statement = $pdo->prepare("SELECT * FROM tbl_payment INNER JOIN tbl_order ON tbl_payment.payment_id=tbl_order.payment_id WHERE keshavarz='$temp'");
$statement->execute();
foreach($statement as $row){
    array_push($balance,$row['paid_amount']);
}
$total_balance=array_sum($balance);


$statement = $pdo->prepare("SELECT * FROM tbl_payment INNER JOIN tbl_order ON tbl_payment.payment_id=tbl_order.payment_id WHERE payment_status=? AND shipping_status=? AND keshavarz='$temp'");
$statement->execute(array('تکمیل پرداخت', 'در حال ارسال'));
$total_order_complete_shipping_pending = $statement->rowCount();
?>

<section class="content">
<div class="row">

            </div>
            <!-- ./col -->
            <div class="col-lg-3 col-xs-6">
              <!-- small box -->
              <div class="small-box bg-maroon">
                <div class="inner">
                  <h3><?php echo $total_balance; ?></h3>

                  <p>موجودی</p>
                </div>
                <div class="icon">
                  <i class="ionicons ion-clipboard"></i>
                </div>
                
              </div>
            </div>
            <!-- ./col -->
            <div class="col-lg-3 col-xs-6">
              <!-- small box -->
              <div class="small-box bg-green">
                <div class="inner">
                  <h3><?php echo $total_order_completed; ?></h3>

                  <p>سفارشات کامل شده</p>
                </div>
                <div class="icon">
                  <i class="ionicons ion-android-checkbox-outline"></i>
                </div>
               
              </div>
            </div>
            <!-- ./col -->
            <div class="col-lg-3 col-xs-6">
              <!-- small box -->
              <div class="small-box bg-aqua">
                <div class="inner">
                  <h3><?php echo $total_shipping_completed; ?></h3>

                  <p>دریافت مشتری</p>
                </div>
                <div class="icon">
                  <i class="ionicons ion-checkmark-circled"></i>
                </div>
                
              </div>
            </div>
			<!-- ./col -->
			
			<div class="col-lg-3 col-xs-6">
				<!-- small box -->
				<div class="small-box bg-orange">
				  <div class="inner">
					<h3><?php echo $total_order_complete_shipping_pending; ?></h3>
  
					<p>در حال ارسال</p>
				  </div>
				  <div class="icon">
					<i class="ionicons ion-load-a"></i>
				  </div>
				  
				</div>
			  </div>
			  </div>
			  </div>

		  </div>
		  
</section>

<?php require_once('footer.php'); ?>