<?php require_once('header.php'); ?>
<!-- login form -->
<?php
if(isset($_POST['form1'])) {
        
    if(empty($_POST['cust_email']) || empty($_POST['cust_password'])) {
        $error_message = "ایمیل و رمز عبور نباید خالی باشد".'<br>';
    } else {
        
        $cust_email = strip_tags($_POST['cust_email']);
        $cust_password = strip_tags($_POST['cust_password']);

        $statement = $pdo->prepare("SELECT * FROM tbl_customer WHERE cust_email=?");
        $statement->execute(array($cust_email));
        $total = $statement->rowCount();
        $result = $statement->fetchAll(PDO::FETCH_ASSOC);
        foreach($result as $row) {
            $cust_status = $row['cust_status'];
            $row_password = $row['cust_password'];
        }

        if($total==0) {
            $error_message .= "آدرس ایمیل مطابقت ندارد".'<br>';
        } else {
            //using MD5 form
            if( $row_password != md5($cust_password) ) {
                $error_message .= "رمز عبور مطابقت ندارد".'<br>';
            } else {
                if($cust_status == 0) {
                    $error_message .= "اکانت شما غیر فعال است".'<br>';
                } else {
                    $_SESSION['customer'] = $row;
                    header("location: ".BASE_URL."dashboard.php");
                }
            }
            
        }
    }
}
?>

<div class="page-banner" style="background-color:#444;background-image: url(assets/uploads/<?php echo $banner_login; ?>);">
    <div class="inner">
        <h1><?php echo "ورود اعضا" ?></h1>
    </div>
</div>

<div class="page">
    <div class="container">
        <div class="row">
        <div class="col-md-12">
            <div>
                <ul style=" text-align:center;">
                    <li class="link-login"><a href="admin/login.php">ورود ادمین</a></li>
                    <li class="link-login"><a href="loginuser.php">ورود کاربر</a></li>
                    <li class="link-login"><a href="keshavarz/login.php">ورود کشاورز</a></li>
                </ul>
            </div>
        </div>
        </div>
    </div>
</div>

<?php require_once('footer.php'); ?>