<?php require_once('header.php');    ; ?>
<div class="page">
    <div class="container">
        <div class="row">
            <div class="col-md-12">
                <p>
                    <h3 style="margin-top:20px;"><?php echo "سفارش با موفقیت انجام شد" ?></h3>
                    <a href="dashboard.php" class="btn btn-success"><?php echo "داشبورد" ?></a>
                </p>
                <?php
                     $temp=$_SESSION['discountid'];
                     if($temp!=0){

                    $statement1 = $pdo->prepare("UPDATE tbl_discount SET code_status='deactive' WHERE discount_id=$temp");
                    $statement1->execute();
                     }
                ?>
            </div>
        </div>
    </div>
</div>

<?php require_once('footer.php'); ?>