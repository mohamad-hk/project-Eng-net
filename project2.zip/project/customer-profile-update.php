<?php require_once('header.php'); ?>

<?php
// Check if the customer is logged in or not
if(!isset($_SESSION['customer'])) {
    header('location: '.BASE_URL.'logout.php');
    exit;
} else {
    // If customer is logged in, but admin make him inactive, then force logout this user.
    $statement = $pdo->prepare("SELECT * FROM tbl_customer WHERE cust_id=? AND cust_status=?");
    $statement->execute(array($_SESSION['customer']['cust_id'],0));
    $total = $statement->rowCount();
    if($total) {
        header('location: '.BASE_URL.'logout.php');
        exit;
    }
}
?>

<?php
if (isset($_POST['form1'])) {

    $valid = 1;

    if(empty($_POST['cust_name'])) {
        $valid = 0;
        $error_message .= "نام نمی تواند خالی باشد"."<br>";
    }

    if(empty($_POST['cust_phone'])) {
        $valid = 0;
        $error_message .= "شماره موبایل نمی تواند خالی باشد"."<br>";
    }

    if(empty($_POST['cust_address'])) {
        $valid = 0;
        $error_message .= "آدرس نمی تواند خالی باشد"."<br>";
    }

    if(empty($_POST['cust_state'])) {
        $valid = 0;
        $error_message .= " استان را انتخاب کنید"."<br>";
    }

    if(empty($_POST['cust_city'])) {
        $valid = 0;
        $error_message .= "شهرستان را انتخاب کنید"."<br>";
    }
    
    if(empty($_POST['cust_district'])) {
        $valid = 0;
        $error_message .= " استان را انتخاب کنید"."<br>";
    }

    if(empty($_POST['cust_zip'])) {
        $valid = 0;
        $error_message .= "کد پستی را وارد کنید"."<br>";
    }
    

    if( empty($_POST['cust_password']) || empty($_POST['cust_re_password']) ) {
        $valid = 0;
        $error_message .= "پسورد نمی تواند خالی باشد"."<br>";
    }

    if( !empty($_POST['cust_password']) && !empty($_POST['cust_re_password']) ) {
        if($_POST['cust_password'] != $_POST['cust_re_password']) {
            $valid = 0;
            $error_message .= "پسورد مطابقت ندارد"."<br>";
        }
    }

    if($valid == 1) {

        // update data into the database
        $statement = $pdo->prepare("UPDATE tbl_customer SET cust_name=?, cust_cname=?, cust_phone=?, cust_address=?,cust_state=?, cust_city=?,cust_district=?, cust_zip=? ,cust_password=? WHERE cust_id=?");
        $statement->execute(array( strip_tags($_POST['cust_name']), strip_tags($_POST['cust_cname']), strip_tags($_POST['cust_phone']),strip_tags($_POST['cust_address']), strip_tags($_POST['cust_state']), strip_tags($_POST['cust_city']), strip_tags($_POST['cust_district']), strip_tags($_POST['cust_zip']), strip_tags(md5($_POST['cust_password'])), $_SESSION['customer']['cust_id']));  
       
        $success_message = "اطلاعات حساب کاربری ویرایش شد";

        $_SESSION['customer']['cust_name'] = $_POST['cust_name'];
        $_SESSION['customer']['cust_cname'] = $_POST['cust_cname'];
        $_SESSION['customer']['cust_phone'] = $_POST['cust_phone'];
        $_SESSION['customer']['cust_address'] = $_POST['cust_address'];
        $_SESSION['customer']['cust_city'] = $_POST['cust_city'];
        $_SESSION['customer']['cust_state'] = $_POST['cust_state'];
        $_SESSION['customer']['cust_district'] = $_POST['cust_district'];
        $_SESSION['customer']['cust_zip'] = $_POST['cust_zip'];
        $_SESSION['customer']['cust_password'] = md5($_POST['cust_password']);
    }

}
?>

<div class="page">
    <div class="container" style=" text-align:right;">
        <div class="row">
            <div class="col-md-12"> 
                <?php require_once('customer-sidebar.php'); ?>
            </div>
            <div class="col-md-12">
                <div class="user-content">
                    <h3>
                        ویرایش اطلاعات
                    </h3>
                    <?php
                    if($error_message != '') {
                        echo "<div class='error' style='padding: 10px;background:#f1f1f1;margin-bottom:20px;'>".$error_message."</div>";
                    }
                    if($success_message != '') {
                        echo "<div class='success' style='padding: 10px;background:#f1f1f1;margin-bottom:20px;'>".$success_message."</div>";
                    }
                    ?>
                    <form action="" method="post">
                        <?php $csrf->echoInputField(); ?>
                        <div class="row">
                            <div class="col-md-6 form-group">
                                <label for="">نام شرکت را وارد کنید</label>
                                <input type="text" class="form-control" style=" text-align:right;" name="cust_cname" value="<?php echo $_SESSION['customer']['cust_cname']; ?>">
                            </div>      

                            <div class="col-md-6 form-group">
                                <label for="">نام و نام خانوادگی *</label>
                                <input type="text" class="form-control" style=" text-align:right;" name="cust_name" value="<?php echo $_SESSION['customer']['cust_name']; ?>">
                            </div>
                            <div class="col-md-6 form-group">
                                <label for="">شماره تماس *</label>
                                <input type="text" class="form-control" style=" text-align:right;" name="cust_phone" value="<?php echo $_SESSION['customer']['cust_phone']; ?>">
                            </div>

                            <div class="col-md-6 form-group">
                                <label for="">آدرس ایمیل *</label>
                                <input type="text" class="form-control" style=" text-align:right;" name="" value="<?php echo $_SESSION['customer']['cust_email']; ?>" disabled>
                            </div>

                            <div class="col-md-12 form-group">
                                <label for="">آدرس *</label>
                                <textarea name="cust_address" class="form-control" style=" text-align:right;" cols="30" rows="10" style="height:70px;"><?php echo $_SESSION['customer']['cust_address']; ?></textarea>
                            </div>

                           <div class="col-md-6 form-group">
                                    <label for="">استان *</label>
                                    <select name="cust_state" class="form-control select2 select-state">
                                        <option value="">استان را انتخاب کنید</option>
                                    <?php
                                    $statement = $pdo->prepare("SELECT * FROM tbl_state ORDER BY state_name ASC");
                                    $statement->execute();
                                    $result = $statement->fetchAll(PDO::FETCH_ASSOC);
                                    foreach ($result as $row) {
                                        ?>
                                        <option value="<?php echo $row['state_name']; ?>"><?php echo $row['state_name']; ?></option>
                                        <?php
                                    }
                                    ?>    
                                    </select>

                                </div>
                            
                            <div class="col-md-6 form-group">
                                    <label for="">شهرستان *</label>
                                    <select name="cust_city" class="form-control select2 select-city ">
                                    <option value="">شهرستان را انتخاب کنید</option> 
                                    </select>
                                </div>
                            

                            <div class="col-md-6 form-group">
                                <label for="">کد پستی *</label>
                                <input type="text" class="form-control" style=" text-align:right;" name="cust_zip" value="<?php echo $_SESSION['customer']['cust_zip']; ?>">
                            </div>         

                            
                            <div class="col-md-6 form-group">
                                    <label for="">محله *</label>
                                    <input type="text" class="form-control" name="cust_district" value="<?php if(isset($_POST['cust_district'])){echo $_POST['cust_district'];} ?>">
                                </div>

                                <div class="col-md-6 form-group">
                                    <label for="">تایید پسورد *</label>
                                    <input type="password" class="form-control" style=" text-align:right;" name="cust_re_password">
                                </div>                            
                            <div class="col-md-6 form-group">
                                    <label for="">پسورد جدید *</label>
                                    <input type="password" class="form-control" style=" text-align:right;" name="cust_password">
                                </div>



                        </div>
                        <input type="Submit" class="btn btn-primary" value="ویرایش" name="form1">
                    </form>
                </div>
            </div>
        </div>
                </div>
            </div>
        </div>
    </div>
</div>



    </div>
</div>


<?php require_once('footer.php'); ?>