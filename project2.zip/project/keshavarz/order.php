<?php require_once('header.php');?>
<section class="content-header">
	<div class="content-header-left">
		<h1>مشاهده سفارشات</h1>
	</div>
</section>

<section class="content">
  <div class="row">
    <div class="col-md-12">
      <div class="box box-info">
        <div class="box-body table-responsive">
          <table id="example1" class="table table-bordered table-hover table-striped">
			<thead>
			    <tr>
			        <th>#</th>
                    <th>نام</th>
                    <th>زمان ثبت سفارش</th>
                    <th>فاکتور</th>
			    </tr>
			</thead>

            <tbody>
            	<?php
            	$i=0;
            	$statement = $pdo->prepare("SELECT * FROM tbl_payment INNER JOIN tbl_order ON tbl_payment.payment_id=tbl_order.payment_id");
            	$statement->execute();
            	$result = $statement->fetchAll(PDO::FETCH_ASSOC);
                $temp=$_SESSION['keshavarz_name'];
                
            	foreach ($result as $row) {
                      if($row['keshavarz']==$temp ){
            		$i++;
            		?>
					<tr class="<?php if($row['payment_status']=='Pending'){echo 'bg-r';}else{echo 'bg-g';} ?>">
	                    <td><?php echo $i; ?></td>
	                    <td>
                             <?php echo $row['customer_name']; ?><br>
                        </td>
                         <td><?php echo $row['payment_date']; ?></td>
                         <td> 

                         
                <?php
                $statement1 = $pdo->prepare("SELECT * FROM tbl_order WHERE payment_id=?");
                $statement1->execute(array($row['payment_id']));
                $result1 = $statement1->fetchAll(PDO::FETCH_ASSOC);
                ?>
            
        <div class="container"  id="report">
            <div class="row">
                <div class="col-md-12">
                    
                    <table id="table1"  class="table table-bordered" style=" width:1000px; border-collapse: collapse; display:none; ">
                        <thead>
                            <tr>
                                <th style= "border:1px solid black; text-align:center;">نام محصول</th>
                                <th style= "border:1px solid black; text-align:center;">نام کشاورز</th>
                                <th style= "border:1px solid black; text-align:center;">نوع دسته بندی</th>
                                <th style= "border:1px solid black; text-align:center;">تعداد</th>
                                <th style= "border:1px solid black; text-align:center;">قیمت</th>
                                <th style= "border:1px solid black; text-align:center;">قیمت نهایی</th>
                               
                            </tr>
                        </thead>
                        <tbody>
                            <?php
                            
                            
                            foreach ($result1 as $row1) {
                                if($temp==$row1['keshavarz']){
                                echo '<tr>';
                                echo '<td width=150px; style= "border:1px solid black; text-align:center;">'. $row1['product_name'].'</td>';
                                echo '<td width=150px; style= "border:1px solid black; text-align:center;">'. $row1['keshavarz'] .'</td>'; 
                                echo '<td width=150px; style= "border:1px solid black; text-align:center;">'. $row1['category'] .'</td>';
                                echo '<td width=10px; style= "border:1px solid black;  text-align:center;">'. $row1['quantity'].'</td>';
                                echo '<td width=10px; style= "border:1px solid black;  text-align:center;">'. $row1['unit_price'].'</td>';    
                                echo '<td width=50px; style= "border:1px solid black;  text-align:center;">'. $row1['unit_price']*$row1['quantity'].'</td>';
                                echo ' </tr>';
                                
                                }
                            }
                            echo'<tr">'.'<td  style= "border:1px solid black;">';
                            echo 'مقدار پرداختی </td>' ;
                            echo ' <td colspan=5 width=850px style= "border:1px solid black;">'.$row['paid_amount'].'</td>'.'</tr>';

                            echo '<tr">'.'<td width=150px style= "border:1px solid black;">';
                            echo  'شماره سفارش:</td>';
                            echo    '<td colspan=5 style= "border:1px solid black;"> '.$row['payment_id'].'</td>'.'</tr>';
                            ?>
                        </tbody>
                    </table>
                    <table id="table2" style=" width: 1000px; border-collapse: collapse; display:none;">
                        <tbody>
                            <tr style="border:1px solid black;">
                                <td width=150px style="border:1px solid black;">نام و نام خانوادگی</td>
                                <td width=850px style="border:1px solid black;"><?php echo $row['customer_name']  ?></td>
                            </tr>
                            <tr style="border:1px solid black;">
                                <td width=150px style="border:1px solid black;">ایمیل</td>
                                <td width=850px style="border:1px solid black;"><?php echo $row['customer_email']  ?></td>
                            </tr>
                            
                        </tbody>
                    </table>

                   <button>print</button>
                    <script>
                        var temp= document.querySelectorAll("table button");
                        temp.forEach(i => {i.addEventListener("click",function(){
                             var a = window.open('', 'report', 'height=1000, width=1000');
                            event.target.previousElementSibling.style.display="block";
                            event.target.previousElementSibling.previousElementSibling.style.display="block";

                             a.document.write('<html>');
                             a.document.write('<body>');
                             a.document.write('<img src="img/logo.png" alt"sasa" width="100" height="100" style="display:inline-block;">');
                             a.document.write('<h1 style="text-align:center;"> همراه سبز</h1>');
                             a.document.write(event.target.previousElementSibling.parentNode.parentNode.parentNode.innerHTML);
                             a.document.write('</body></html>');
                             a.document.close();
                            event.target.previousElementSibling.style.display="none";
                            event.target.previousElementSibling.previousElementSibling.style.display="none";
                             
                             a.print();
                            }) 
                        });
               </script>
            </div>
        </div>

                         
                         </td>
                        <?php }}?>


</tbody>
</table>
</section>


<div class="modal fade" id="confirm-delete" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>
                <h4 class="modal-title" id="myModalLabel">حذف اطلاعات</h4>
            </div>
            <div class="modal-body">
               آیا از حذف آن اطمینان دارید؟
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-default" data-dismiss="modal">لغو</button>
                <a class="btn btn-danger btn-ok">حذف</a>
            </div>
        </div>
    </div>
</div>
<?php require_once('footer.php'); ?>